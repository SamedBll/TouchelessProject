﻿Public Class Form1
    Dim BMP As New Drawing.Bitmap(1280, 720)
    Dim GFX As System.Drawing.Graphics = System.Drawing.Graphics.FromImage(BMP)

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        GFX.CopyFromScreen(New Drawing.Point(0, 0),
        New Drawing.Point(0, 0), BMP.Size)
        PictureBox1.Image = BMP
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Enabled = False
        PictureBox1.SizeMode = PictureBoxSizeMode.Normal
        Timer2.Enabled = True
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        GFX.CopyFromScreen(New Drawing.Point(MousePosition.X, MousePosition.Y),
       New Drawing.Point(0, 0), BMP.Size)
        PictureBox1.Image = BMP
    End Sub
End Class
