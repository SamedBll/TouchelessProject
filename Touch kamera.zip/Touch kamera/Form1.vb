﻿Public Class Form1
    'Webcam
    Public Touchless As New TouchlessLib.TouchlessMgr
    Public Camera1 As TouchlessLib.Camera = Touchless.Cameras.ElementAt(0)

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Touchless.CurrentCamera = Camera1
        Touchless.CurrentCamera.CaptureHeight = 480
        Touchless.CurrentCamera.CaptureWidth = 640
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        PictureBox1.Image = Touchless.CurrentCamera.GetCurrentImage
    End Sub
End Class
